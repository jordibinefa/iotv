import iotv
import time

# Configuration IO
vertebraA = "0x0"
vertebraD = "0x1"
# Forward (right)
bMotorA = 0
# Backward (left)
bMotorB = 1
bSolenoide = 2
# Left sensor
bSensorE = 5
# Right sensor
bSensorD = 6
# Emergency button
bEmergencia = 7
# DAC channel 0 (+1 for aout function)
canalVel = 1

print("=== PING-PONG WITH EMERGENCY ===")
print("Press emergency button to stop")
print()

# Set speed 50%
iotv.aout(vertebraA, 'a', canalVel, iotv.v2aout(5.0))
print("Speed: 50%")

# Initial direction: forward (right)
direction = 1

# Start motor forward
iotv.doutbit(vertebraD, 'a', bMotorA, 1)
iotv.doutbit(vertebraD, 'a', bMotorB, 0)
print("-> Motor forward")

while True:
    # Check emergency
    emergency = iotv.dinbit(vertebraD, 'b', bEmergencia)
    if emergency == 1:
        print("WARNING: EMERGENCY ACTIVATED - Motor stopped")
        iotv.doutbit(vertebraD, 'a', bMotorA, 0)
        iotv.doutbit(vertebraD, 'a', bMotorB, 0)
        time.sleep(0.5)
        continue
    
    # Activate motor based on direction
    if direction == 1:
        iotv.doutbit(vertebraD, 'a', bMotorA, 1)
        iotv.doutbit(vertebraD, 'a', bMotorB, 0)
    if direction != 1:
        iotv.doutbit(vertebraD, 'a', bMotorA, 0)
        iotv.doutbit(vertebraD, 'a', bMotorB, 1)
    

        
    sensorE = iotv.dinbit(vertebraD, 'b', bSensorE)
    sensorD = iotv.dinbit(vertebraD, 'b', bSensorD)
        
    # Check sensor based on direction (nested if, no or)
    detected = 0
    if direction == 1:
        if sensorD == 1:
            detected = 1
    if direction != 1:
        if sensorE == 1:
            detected = 1
        
    if detected == 1:
        if direction == 1:
            sensor_name = "right"
        if direction != 1:
            sensor_name = "left"
        direction = direction * -1
        print("Sensor", sensor_name, "detected")
        if direction == 1:
            print("-> Motor forward")
        else:
            print("<- Motor backward")
    
    time.sleep(0.01)


print("Program end")
