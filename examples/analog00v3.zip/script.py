import iotv
import time

while True:
    adc = iotv.ain("0x0", "b", 1)
    voltage_adc = iotv.ain2v(adc)
    voltage_dac = (voltage_adc + 10) / 2
    dac = iotv.v2aout(voltage_dac)
    iotv.aout("0x0", "a", 1, dac)
    pct = int((voltage_dac / 10) * 100)
    print("AI1:", voltage_adc, "V -> AO1:", voltage_dac, "V (", pct, "%)")

    adc4 = iotv.ain("0x0", "b", 4)
    voltage_adc4 = iotv.ain2v(adc4)
    voltage_dac4 = (voltage_adc4 + 10) / 2
    dac4 = iotv.v2aout(voltage_dac4)
    iotv.aout("0x0", "a", 4, dac4)
    pct4 = int((voltage_dac4 / 10) * 100)
    print("AI4:", voltage_adc4, "V -> AO4:", voltage_dac4, "V (", pct4, "%)")

    time.sleep(0.2)
