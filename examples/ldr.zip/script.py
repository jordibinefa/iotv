import iotv
import time

print("=== LDR Sensor amb Bombeta ===")
print("Mou el slider per simular llum")
print()

while True:
    adc = iotv.ain("0x0", "b", 1)
    v = iotv.ain2v(adc)
    pct = (v + 10) / 20
    lux = int(pct * 65535)
    print("Llum:", lux, "lux (", int(pct * 100), "%)")
    time.sleep(0.3)
