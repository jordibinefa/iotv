import iotv
import time

print("=== Digital IO: Switch -> LED ===")
print("Toggle the switch to control the LED")

while True:
    entrada = iotv.dinbit("0x0", "b", 0)
    iotv.doutbit("0x0", "a", 0, entrada)
    if entrada == 1:
        print("Switch ON -> LED ON")
    else:
        print("Switch OFF -> LED OFF")
    time.sleep(0.3)
