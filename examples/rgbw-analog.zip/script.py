import iotv
import time

print("=== RGBW LED Analog (0-10V) ===")
print("4 sliders: R(CH1) G(CH2) B(CH3) W(CH4)")
print()

while True:
    r = iotv.ain2v(iotv.ain("0x0", "b", 1))
    g = iotv.ain2v(iotv.ain("0x0", "b", 2))
    b = iotv.ain2v(iotv.ain("0x0", "b", 3))
    w = iotv.ain2v(iotv.ain("0x0", "b", 4))

    # Write to DAC (passthrough for visualization)
    iotv.aout("0x0", "a", 1, iotv.v2aout(r))
    iotv.aout("0x0", "a", 2, iotv.v2aout(g))
    iotv.aout("0x0", "a", 3, iotv.v2aout(b))
    iotv.aout("0x0", "a", 4, iotv.v2aout(w))

    print("R:", int(r*10)/10, "G:", int(g*10)/10, "B:", int(b*10)/10, "W:", int(w*10)/10, "V")
    time.sleep(0.2)
