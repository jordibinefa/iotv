import iotv
import time

print("=== RGBW LED Digital ===")
print("Toggle switches to change color")
print()

while True:
    r = iotv.dinbit("0x0", "b", 0)
    g = iotv.dinbit("0x0", "b", 1)
    b = iotv.dinbit("0x0", "b", 2)
    w = iotv.dinbit("0x0", "b", 3)

    # Copy to output for visualization
    iotv.doutbit("0x0", "a", 0, r)
    iotv.doutbit("0x0", "a", 1, g)
    iotv.doutbit("0x0", "a", 2, b)
    iotv.doutbit("0x0", "a", 3, w)

    print("R:", r, "G:", g, "B:", b, "W:", w)
    time.sleep(0.2)
