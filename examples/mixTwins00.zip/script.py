import iotv
import time

vertebraD = "0x1"
vertebraA = "0x0"
bMotorA = 0
bMotorB = 1
bSolenoide = 2
bSensorE = 5
bSensorD = 6
bEmergencia = 7
canalVel = 1

print("=== PING-PONG WITH SPEED SLIDER ===")
print("Use the Speed Control slider to set motor speed")
print()

# Initial: drop a box
iotv.doutbit(vertebraD, 'a', bSolenoide, 1)
time.sleep(0.1)
iotv.doutbit(vertebraD, 'a', bSolenoide, 0)
print("Box dropped!")

# Direction forward
direction = 1
iotv.doutbit(vertebraD, 'a', bMotorA, 1)
iotv.doutbit(vertebraD, 'a', bMotorB, 0)
print("-> Motor forward")

while True:
    # Read speed from twin slider (ADC input channel 1, 0-10V)
    adc = iotv.ain(vertebraA, "b", canalVel)
    speed_v = iotv.ain2v(adc)
    # Map from -10..10 slider to 0..10V DAC proportionally
    speed_dac = max(0, min(10, speed_v))
    dac = iotv.v2aout(speed_dac)
    iotv.aout(vertebraA, "a", canalVel, dac)

    # Check emergency
    emergency = iotv.dinbit(vertebraD, 'b', bEmergencia)
    if emergency == 1:
        print("EMERGENCY - stopped")
        iotv.doutbit(vertebraD, 'a', bMotorA, 0)
        iotv.doutbit(vertebraD, 'a', bMotorB, 0)
        time.sleep(0.5)
        continue

    # Activate motor
    if direction == 1:
        iotv.doutbit(vertebraD, 'a', bMotorA, 1)
        iotv.doutbit(vertebraD, 'a', bMotorB, 0)
    if direction != 1:
        iotv.doutbit(vertebraD, 'a', bMotorA, 0)
        iotv.doutbit(vertebraD, 'a', bMotorB, 1)

    # Check sensors
    sensorE = iotv.dinbit(vertebraD, 'b', bSensorE)
    sensorD = iotv.dinbit(vertebraD, 'b', bSensorD)

    detected = 0
    if direction == 1:
        if sensorD == 1:
            detected = 1
    if direction != 1:
        if sensorE == 1:
            detected = 1

    if detected == 1:
        direction = direction * -1
        if direction == 1:
            print("-> Forward (speed:", speed_dac, "V)")
        else:
            print("<- Backward (speed:", speed_dac, "V)")

    time.sleep(0.01)
