import iotv
import time

# =============================================
# ELEVATOR 3-FLOOR CONTROLLER
# =============================================
# Digital Outputs (0x0-A):
#   bit0=Motor_Up bit1=Motor_Down bit2=Brake
#   bit3=Door_Open bit4=Door_Close
#   bit5=Disp_P0 bit6=Disp_P1 bit7=Disp_P2
# Digital Outputs (0x1-A):
#   bit0=Door_Light bit1=Alarm_Light
# Analog Output (0x0-A ch1): Motor_Speed
# Digital Inputs (0x0-B):
#   bit0=Cab0 bit1=Cab1 bit2=Cab2
#   bit3=Alarm bit4=Overload
#   bit5=P0Up bit6=P1Up bit7=P1Down
# Digital Inputs (0x1-B):
#   bit0=P2Down bit1=DoorOpenBtn bit2=DoorCloseBtn
#   bit3=DoorSafety
# Analog Input (0x0-B ch1): Encoder
# =============================================

# Output bits
bMotorUp = 0
bMotorDown = 1
bBrake = 2
bDoorOpen = 3
bDoorClose = 4
bDispP0 = 5
bDispP1 = 6
bDispP2 = 7
bDoorLight = 0
bAlarmLight = 1

# Input bits
bCabCall0 = 0
bCabCall1 = 1
bCabCall2 = 2
bCabAlarm = 3
bCabOverload = 4
bP0Up = 5
bP1Up = 6
bP1Down = 7
bP2Down = 0
bDoorOpenBtn = 1
bDoorCloseBtn = 2
bDoorSafety = 3

# Constants
FLOOR_POS_0 = 0.0
FLOOR_POS_1 = 3.0
FLOOR_POS_2 = 6.0
MARGIN = 0.2
SPEED_MAX = 4095
SPEED_MED = 2048
SPEED_LOW = 800
DOOR_TIME = 3.0
WAIT_TIME = 5.0

# States
ST_WAIT = 0
ST_MOVE = 1
ST_OPEN = 2
ST_OPENED = 3
ST_CLOSE = 4
ST_EMERG = 5

# Helper: read encoder position (0-6 meters)
def read_encoder():
    raw = iotv.ain("0x0", "b", 1)
    voltage = iotv.ain2v(raw)
    pos = (voltage + 10.0) / 20.0 * 6.0
    if pos < 0.0:
        pos = 0.0
    if pos > 6.0:
        pos = 6.0
    return pos

# Helper: get floor position in meters
def get_floor_pos(floor):
    if floor == 0:
        return FLOOR_POS_0
    if floor == 1:
        return FLOOR_POS_1
    return FLOOR_POS_2

# Helper: detect floor from position
def pos_to_floor(pos):
    if abs(pos - FLOOR_POS_0) < MARGIN:
        return 0
    if abs(pos - FLOOR_POS_1) < MARGIN:
        return 1
    if abs(pos - FLOOR_POS_2) < MARGIN:
        return 2
    return -1

# Helper: stop all motors
def stop_motor():
    iotv.doutbit("0x0", "a", bMotorUp, 0)
    iotv.doutbit("0x0", "a", bMotorDown, 0)
    iotv.doutbit("0x0", "a", bBrake, 1)
    iotv.aout("0x0", "a", 1, 0)

# Helper: update floor display
def show_floor(floor):
    iotv.doutbit("0x0", "a", bDispP0, 0)
    iotv.doutbit("0x0", "a", bDispP1, 0)
    iotv.doutbit("0x0", "a", bDispP2, 0)
    if floor == 0:
        iotv.doutbit("0x0", "a", bDispP0, 1)
    if floor == 1:
        iotv.doutbit("0x0", "a", bDispP1, 1)
    if floor == 2:
        iotv.doutbit("0x0", "a", bDispP2, 1)

# Helper: check emergency
def is_emergency():
    alarm = iotv.dinbit("0x0", "b", bCabAlarm)
    overload = iotv.dinbit("0x0", "b", bCabOverload)
    if alarm == 1:
        return 1
    if overload == 1:
        return 1
    return 0

# =============================================
# MAIN
# =============================================
print("=== ELEVATOR CONTROLLER v1.0 ===")
print("P0=0m  P1=3m  P2=6m")
print()

# Initialize
stop_motor()
show_floor(0)
iotv.doutbit("0x0", "a", bDoorOpen, 0)
iotv.doutbit("0x0", "a", bDoorClose, 0)
iotv.doutbit("0x1", "a", bDoorLight, 0)
iotv.doutbit("0x1", "a", bAlarmLight, 0)
print("Initialized at P0")

# State variables (all at top level, no global needed)
state = ST_WAIT
current_floor = 0
target_floor = -1
direction = 0
pending_0 = 0
pending_1 = 0
pending_2 = 0
door_timer = 0.0

while True:
    # Read call buttons (accumulate pending calls)
    if iotv.dinbit("0x0", "b", bCabCall0) == 1:
        pending_0 = 1
    if iotv.dinbit("0x0", "b", bP0Up) == 1:
        pending_0 = 1
    if iotv.dinbit("0x0", "b", bCabCall1) == 1:
        pending_1 = 1
    if iotv.dinbit("0x0", "b", bP1Up) == 1:
        pending_1 = 1
    if iotv.dinbit("0x0", "b", bP1Down) == 1:
        pending_1 = 1
    if iotv.dinbit("0x0", "b", bCabCall2) == 1:
        pending_2 = 1
    if iotv.dinbit("0x1", "b", bP2Down) == 1:
        pending_2 = 1

    # ---- WAITING ----
    if state == ST_WAIT:
        if is_emergency() == 1:
            state = ST_EMERG
            print("EMERGENCY!")
        else:
            # Select target from pending calls
            target_floor = -1
            if direction >= 0:
                if current_floor < 1:
                    if pending_1 == 1:
                        target_floor = 1
                if current_floor < 2:
                    if pending_2 == 1:
                        if target_floor < 0:
                            target_floor = 2
            if target_floor < 0:
                if direction <= 0:
                    if current_floor > 1:
                        if pending_1 == 1:
                            target_floor = 1
                    if current_floor > 0:
                        if pending_0 == 1:
                            if target_floor < 0:
                                target_floor = 0
            if target_floor < 0:
                if pending_0 == 1:
                    target_floor = 0
                elif pending_1 == 1:
                    target_floor = 1
                elif pending_2 == 1:
                    target_floor = 2

            if target_floor >= 0:
                if target_floor == current_floor:
                    # Already here
                    if target_floor == 0:
                        pending_0 = 0
                    if target_floor == 1:
                        pending_1 = 0
                    if target_floor == 2:
                        pending_2 = 0
                    state = ST_OPEN
                    print(f"At P{current_floor}, opening doors")
                else:
                    # Start moving
                    if target_floor > current_floor:
                        direction = 1
                        iotv.doutbit("0x0", "a", bMotorUp, 1)
                        iotv.doutbit("0x0", "a", bMotorDown, 0)
                        print(f"UP to P{target_floor}")
                    else:
                        direction = -1
                        iotv.doutbit("0x0", "a", bMotorUp, 0)
                        iotv.doutbit("0x0", "a", bMotorDown, 1)
                        print(f"DOWN to P{target_floor}")
                    iotv.doutbit("0x0", "a", bBrake, 0)
                    iotv.aout("0x0", "a", 1, SPEED_MAX)
                    state = ST_MOVE

    # ---- MOVING ----
    if state == ST_MOVE:
        if is_emergency() == 1:
            stop_motor()
            state = ST_EMERG
            print("EMERGENCY during move!")
        else:
            pos = read_encoder()
            target_pos = get_floor_pos(target_floor)
            dist = abs(target_pos - pos)

            # Speed profile
            if dist > 1.5:
                iotv.aout("0x0", "a", 1, SPEED_MAX)
            elif dist > 0.5:
                iotv.aout("0x0", "a", 1, SPEED_MED)
            else:
                iotv.aout("0x0", "a", 1, SPEED_LOW)

            # Arrived?
            if dist < MARGIN:
                stop_motor()
                current_floor = target_floor
                show_floor(current_floor)
                if current_floor == 0:
                    pending_0 = 0
                if current_floor == 1:
                    pending_1 = 0
                if current_floor == 2:
                    pending_2 = 0
                print(f"Arrived P{current_floor}")
                state = ST_OPEN

    # ---- DOORS OPENING ----
    if state == ST_OPEN:
        safety = iotv.dinbit("0x1", "b", bDoorSafety)
        if safety == 1:
            print("Safety active, skip open")
            state = ST_WAIT
        else:
            iotv.doutbit("0x0", "a", bDoorOpen, 1)
            iotv.doutbit("0x0", "a", bDoorClose, 0)
            iotv.doutbit("0x1", "a", bDoorLight, 1)
            door_timer = time.time()
            state = ST_OPENED
            print("Doors opening...")

    # ---- DOORS OPEN (waiting) ----
    if state == ST_OPENED:
        elapsed = time.time() - door_timer

        # Manual close
        close_btn = iotv.dinbit("0x1", "b", bDoorCloseBtn)
        if close_btn == 1:
            if elapsed > 1.0:
                state = ST_CLOSE
                print("Manual close")

        # Timeout
        if elapsed > DOOR_TIME + WAIT_TIME:
            state = ST_CLOSE
            print("Timeout, closing")

    # ---- DOORS CLOSING ----
    if state == ST_CLOSE:
        safety = iotv.dinbit("0x1", "b", bDoorSafety)
        if safety == 1:
            print("Obstacle! Reopening")
            state = ST_OPEN
        else:
            iotv.doutbit("0x0", "a", bDoorOpen, 0)
            iotv.doutbit("0x0", "a", bDoorClose, 1)
            time.sleep(1.5)
            iotv.doutbit("0x0", "a", bDoorClose, 0)
            iotv.doutbit("0x1", "a", bDoorLight, 0)
            print("Doors closed")
            state = ST_WAIT

    # ---- EMERGENCY ----
    if state == ST_EMERG:
        stop_motor()
        iotv.doutbit("0x1", "a", bAlarmLight, 1)
        iotv.doutbit("0x0", "a", bDoorOpen, 1)
        print("!!! EMERGENCY !!!")

        # Wait for clear
        while True:
            a = iotv.dinbit("0x0", "b", bCabAlarm)
            o = iotv.dinbit("0x0", "b", bCabOverload)
            if a == 0:
                if o == 0:
                    break
            time.sleep(0.2)

        # Reset
        iotv.doutbit("0x1", "a", bAlarmLight, 0)
        iotv.doutbit("0x0", "a", bDoorOpen, 0)
        iotv.doutbit("0x0", "a", bDoorClose, 1)
        time.sleep(1.0)
        iotv.doutbit("0x0", "a", bDoorClose, 0)
        print("Emergency cleared")

        pos = read_encoder()
        detected = pos_to_floor(pos)
        if detected >= 0:
            current_floor = detected
        show_floor(current_floor)
        state = ST_WAIT

    # Loop delay
    time.sleep(0.1)
