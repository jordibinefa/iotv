while True:
    print("speed_dac: ",speed_dac)
    time.sleep(0.5)