import iotv
import time

while True:
  entrada = iotv.din("0x0", 'b')
  iotv.dout("0x0","a",entrada)
  print(entrada)
  time.sleep(0.5)
