import paho.mqtt.client as mqtt
import time
import iotv

# --- CONFIGURACIÓ ---
ROOT_TOPIC = "/manel1234"
# Adreça de la vèrtebra
VERTEBRA = "0x0"
RIB_OUT = "a"
RIB_IN = "b"

# Estat global per detectar canvis
last_buttons_value = -1

# --- CALLBACKS (Nivell Global) ---

def handle_message(client, userdata, msg):
    # ELIMINAT: global ROOT_TOPIC (causa SyntaxError)
    payload = msg.payload
    topic = msg.topic
    
    # Comprovem el topic de LEDs
    if topic == ROOT_TOPIC + "/leds":
        if payload == "ON":
            iotv.dout(VERTEBRA, RIB_OUT, 0xFF)
        
        if payload == "OFF":
            iotv.dout(VERTEBRA, RIB_OUT, 0x00)
            
        # Si no és ON/OFF, intentem tractar-lo com a número
        if payload != "ON":
            if payload != "OFF":
                val = int(payload)
                iotv.dout(VERTEBRA, RIB_OUT, val)
            
    # Petició d'estat de botons
    if topic == ROOT_TOPIC + "/buttonsReq":
        buttons = iotv.din(VERTEBRA, RIB_IN)
        # Construcció manual de JSON
        json_resp = '{"buttons": ' + str(buttons) + '}'
        client.publish(ROOT_TOPIC + "/buttons", json_resp)

def on_connect(client, userdata, flags, rc):
    # ELIMINAT: global ROOT_TOPIC
    if rc == 0:
        print("Connectat al broker")
        client.subscribe(ROOT_TOPIC + "/leds")
        client.subscribe(ROOT_TOPIC + "/buttonsReq")
        print("Subscrit a:", ROOT_TOPIC)
    else:
        print("Error de connexió:", rc)

# --- PROGRAMA PRINCIPAL ---

client = mqtt.Client("iot-vertebrae-manel")
client.on_connect = on_connect
client.on_message = handle_message

client.connect("broker.emqx.io", 8084, 60)
client.loop_start()

print("Programa actiu. Arrel:", ROOT_TOPIC)

# Bucle de polling (limitat a 120 iteracions per seguretat)
# for i in range(120):
while True:
    current_buttons = iotv.din(VERTEBRA, RIB_IN)
    
    if current_buttons != last_buttons_value:
        # Publicació per canvi
        client.publish(ROOT_TOPIC + "/buttons", str(current_buttons))
        print("Canvi detectat:", current_buttons)
        last_buttons_value = current_buttons
    
    time.sleep(0.5)

client.loop_stop()
client.disconnect()
print("Fi del programa")