import iotv
import time

print("=== BME280 Sensor Simulator ===")
print()

while True:
    v_t = iotv.ain2v(iotv.ain("0x0", "b", 1))
    v_h = iotv.ain2v(iotv.ain("0x0", "b", 2))
    v_p = iotv.ain2v(iotv.ain("0x0", "b", 3))

    temp = (v_t + 10) / 20 * 125 - 40
    hum = (v_h + 10) / 20 * 100
    pres = (v_p + 10) / 20 * 800 + 300

    t_i = int(temp * 10) / 10
    h_i = int(hum)
    p_i = int(pres)

    print("T:", t_i, "C | H:", h_i, "% | P:", p_i, "hPa")
    time.sleep(0.5)